// /app/api/shops/today-supports/route.ts
import { NextResponse } from "next/server";
import { createClientServer } from "@/lib/supabase/server";
import { getOrSetSessionId } from "@/lib/session";

export async function GET() {
  try {
    const supabase = await createClientServer();
    const sid = await getOrSetSessionId(); // ✅ 必ず await

    // 今日の開始と終了（UTC基準 → 必要なら JST に変換）
    const today = new Date();
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const endOfDay = new Date(startOfDay);
    endOfDay.setDate(endOfDay.getDate() + 1);

    // 今日の応援済み shopid を取得
    const { data, error } = await supabase
      .from("support_events")
      .select("shopid")
      .eq("session_id", sid)
      .gte("created_at", startOfDay.toISOString())
      .lt("created_at", endOfDay.toISOString());

    if (error) {
      console.error("today-supports error:", error);
      return NextResponse.json({ supported: [] }, { status: 500 });
    }

    const supported = data.map((row) => row.shopid);
    return NextResponse.json({ supported });
  } catch (e) {
    console.error("today-supports unexpected error:", e);
    return NextResponse.json({ supported: [] }, { status: 500 });
  }
}
