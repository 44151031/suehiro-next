// ? /src/lib/campaignMaster.ts
import { campaignsA } from "./campaignMasterA";
import { campaignsB } from "./campaignMasterB";
import { campaignsC } from "./campaignMasterC";

export const campaigns = [...campaignsA, ...campaignsB, ...campaignsC];