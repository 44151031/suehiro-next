"use client";

import { useState } from "react";
import { toggleSupport } from "@/app/actions/support";
import { toast } from "sonner";

type Props = {
  shopid: string;
  initiallyLiked?: boolean; // ✅ 追加
};

export default function SupportButton({ shopid, initiallyLiked = false }: Props) {
  const [likes, setLikes] = useState<number>(0);
  const [liked, setLiked] = useState<boolean>(initiallyLiked);
  const [pending, setPending] = useState<boolean>(false);

  const handleClick = async () => {
    if (pending) return;
    setPending(true);
    try {
      const result = await toggleSupport(shopid);
      if (result.ok) {
        setLiked(result.liked);
        setLikes(result.likes);

        if (result.liked) {
          toast.success(result.message || "応援ありがとうございます！");
        }
      } else {
        toast.error(result.message || "エラーが発生しました");
      }
    } catch (e) {
      console.error(e);
      toast.error("通信エラーが発生しました");
    } finally {
      setPending(false);
    }
  };

  return (
    <button
      onClick={handleClick}
      disabled={pending}
      aria-disabled={pending}
      className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm transition ${
        liked ? "bg-pink-100 text-pink-600" : "bg-gray-100 text-gray-600"
      } ${pending ? "opacity-60 pointer-events-none" : ""}`}
    >
      <span className="text-lg">{liked ? "♥" : "♡"}</span>
      <span>{likes > 10 ? "10+" : likes}</span>
    </button>
  );
}
