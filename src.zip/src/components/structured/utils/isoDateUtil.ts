export function toISODate(date) {
  return `${date}T00:00:00+09:00`;
}
