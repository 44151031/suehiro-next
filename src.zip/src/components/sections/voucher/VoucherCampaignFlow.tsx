export default function VoucherCampaignFlow() {
  return (
    <section className="mt-6 bg-white p-4 rounded shadow">
      <h2 className="text-lg font-semibold mb-2">購入〜利用の流れ</h2>
      <p className="text-sm text-gray-700">詳細は今後追加予定です。</p>
    </section>
  );
}