export default function VoucherCampaignStoreTypes() {
  return (
    <section className="mt-6 bg-white p-4 rounded shadow">
      <h2 className="text-lg font-semibold mb-2">利用可能店舗ジャンル</h2>
      <p className="text-sm text-gray-700">詳細は今後追加予定です。</p>
    </section>
  );
}