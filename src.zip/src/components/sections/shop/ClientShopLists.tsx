"use client";

import { useState, useEffect } from "react";
import { getShopRanking } from "@/app/actions/support";
import GenreShopLists from "@/components/sections/shop/GenreShopLists";
import type { Shop } from "@/types/shop";

type Props = {
  shopListByGenre: Record<string, Shop[]>;
  detailsJsonPath: string;
};

export default function ClientShopLists({ shopListByGenre, detailsJsonPath }: Props) {
  const [sortMode, setSortMode] = useState<"default" | "support">("default");
  const [ranking, setRanking] = useState<{ shopid: string; likes: number }[]>([]);
  const [supportedShopIds, setSupportedShopIds] = useState<string[]>([]);

  // ✅ 今日の応援済み店舗一覧を1回だけ取得
  useEffect(() => {
    const fetchTodaySupports = async () => {
      try {
        const res = await fetch("/api/shops/today-supports", { cache: "no-store" });
        if (res.ok) {
          const data = await res.json();
          setSupportedShopIds(data.supported || []);
        }
      } catch (err) {
        console.error("today-supports fetch error:", err);
      }
    };
    fetchTodaySupports();
  }, []);

  // ✅ 応援順ランキングを取得
  useEffect(() => {
    if (sortMode === "support") {
      (async () => {
        const data = await getShopRanking();
        setRanking(data);
      })();
    }
  }, [sortMode]);

  return (
    <>
      {/* ✅ ソート切り替え UI */}
      <div className="mb-4 flex justify-end">
        <select
          value={sortMode}
          onChange={(e) => setSortMode(e.target.value as "default" | "support")}
          className="border rounded px-3 py-1 text-sm"
        >
          <option value="default">通常順</option>
          <option value="support">応援順</option>
        </select>
      </div>

      <GenreShopLists
        shopListByGenre={shopListByGenre}
        detailsJsonPath={detailsJsonPath}
        sortMode={sortMode}
        ranking={ranking}
        supportedShopIds={supportedShopIds} // ✅ 追加
      />
    </>
  );
}
